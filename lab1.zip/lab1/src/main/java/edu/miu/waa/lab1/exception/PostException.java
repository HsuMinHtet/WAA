package edu.miu.waa.lab1.exception;

public class PostException extends RuntimeException{
    public PostException(String msg){super(msg);}
}
