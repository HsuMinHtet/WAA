import "./NewPost.css";
import { useRef } from "react";
import axios from "axios";

const NewPost = (props) => {
  const newPostForm = useRef();

  const addButtonClicked = () => {
    const form = newPostForm.current;
    const data = {
      title: form["title"].value,
      content: form["content"].value,
      author: form["author"].value,
    };
    axios
      .post("http://localhost:8080/posts/", data)
      .then((reponse) => {
        props.changeFetchFlag();
      })
      .catch();
  };

  return (
    <div className="NewPost">
      <form ref={newPostForm}>
        <h1>Add Post</h1>
        <label>Title: </label>
        <input type="text" label={"title"} name={"title"} />
        <label>Content: </label>
        <input type="text" label={"content"} name={"content"} />
        <label>Author: </label>
        <input type="text" label={"author"} name={"author"} />
      </form>
      <button onClick={addButtonClicked}> Add Post</button>
    </div>
  );
};
export default NewPost;
