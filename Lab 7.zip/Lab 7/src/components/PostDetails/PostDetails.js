import { Fragment, useEffect, useState } from "react";
import Dashboard from "../../containers/DashBoard/Dashboard";
import axios from "axios";
import Comment from "../Comment/Comment";
const PostDetails = (props) => {
  console.log("Post Details" + props.id);

  const [commentDetail, setCommentDetail] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8080/posts/" + props.id + "/comment")
      .then((response) => {
        setCommentDetail(response.data);
        console.log("Comment", response.data);
      })
      .catch((err) => console.log(err.message));
  }, [props.id]);

  const space = <Fragment>&nbsp;&nbsp;</Fragment>;

  return (
    <div>
      <h3>ID: {props.id}</h3>
      <h3>Title: {props.title}</h3>
      <h3>Author: {props.author}</h3>

      <div style={{ textAlign: "left" }}>
        {space} Comments <br />
        {commentDetail != null
          ? commentDetail.map((c) => {
              return <Comment comment={c.name} key={c.id} />;
            })
          : null}
      </div>

      <div>
        <input
          type="button"
          value="delete"
          onClick={() => props.deletePost(props.id)}
        />
        <input type="button" value="edit" onClick={props.editPost} />
      </div>
    </div>
  );
};

export default PostDetails;
