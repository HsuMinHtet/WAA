import Post from "../../components/Post/Post";

const Posts = (props) => {
  const postList = props.posts.map((post) => {
    return (
      <Post
        title={post.title}
        author={post.author}
        id={post.id}
        key={post.id}
        setSelected={() => {
          props.setSelected(post.id);
        }}
      />
    );
  });
  return postList;
};
export default Posts;
