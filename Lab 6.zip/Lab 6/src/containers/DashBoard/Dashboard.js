import React, { useState } from "react";
import Posts from "../Posts/Posts";
import PostDetails from "../../components/PostDetails/PostDetails";

const Dashboard = () => {
  const [selectedState, setSelectedState] = useState(0);
  const [selectedTitle, setSelectedTitle] = useState(null);
  const [selectedAuthor, setSelectedAuthor] = useState(null);
  const [postsState, setPostsState] = useState([
    { id: 1, title: "Business", author: "Timmy" },
    { id: 2, title: "Education", author: "Jhon" },
    { id: 3, title: "Science", author: "Rose" },
  ]);

  const [postState, setPostState] = useState({
    title: "",
  });

  const handleInputChange = (event) => {
    //setPostState(event.target.value);
    const { name, value } = event.target;
    setPostState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const addButtonClicked = () => {
    const titleValue = postState.title;

    setPostsState((prevPosts) =>
      prevPosts.map((post) =>
        post.id === 1 ? { ...post, title: titleValue } : post
      )
    );
  };

  const setSelected = (id) => {
    postsState.map((post) => {
      if (post.id == id) {
        setSelectedTitle(post.title);
        setSelectedAuthor(post.author);
      }
    });
    setSelectedState(id);
  };

  return (
    <div>
      <Posts posts={postsState} setSelected={setSelected} />
      <div>
        <input label={"title"} name={"title"} onChange={handleInputChange} />
        <button onClick={addButtonClicked}>Change Name</button>
      </div>
      <div>
        <PostDetails
          author={selectedAuthor}
          title={selectedTitle}
          id={selectedState}
        />
      </div>
    </div>
  );
};

export default Dashboard;
