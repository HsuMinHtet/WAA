import Dashboard from "../../containers/DashBoard/Dashboard";
const PostDetails = (props) => {
  return (
    <div className="ProductDetail">
      <h3>ID: {props.id}</h3>
      <h3>Title: {props.title}</h3>
      <h3>Author: {props.author}</h3>
      <div className="Edit">
        <input type="button" value="edit" onClick={props.deleteProduct} />
        <input type="button" value="delete" onClick={props.deleteProduct} />
      </div>
    </div>
  );
};

export default PostDetails;
