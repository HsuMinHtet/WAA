import { useMemo, useState } from "react";

const Post = (props) => {
  console.log("Post:::");
  const memorizedComponent = useMemo(() => {
    console.log("Rendering Post");
    return (
      <div className="Content">
        <div className="Post" onClick={props.setSelected}>
          <h3>ID: {props.id}</h3>
          <h3>Title: {props.title}</h3>
          <h3>Author: {props.author}</h3>
        </div>
      </div>
    );
  }, []);
  return memorizedComponent;
};

export default Post;
