import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import Dashboard from "../../containers/DashBoard/Dashboard";
import axios from "axios";
import Comment from "../Comment/Comment";

const PostDetails = (props) => {
  // console.log("PostDetails:::");
  const [commentDetail, setCommentDetail] = useState([]);
  const [value, setValue] = useState(0); // click button , this will change the value for useMemo example
  const textField = useRef();

  useEffect(() => {
    axios
      .get("http://localhost:8080/posts/" + props.id + "/comment")
      .then((response) => {
        setCommentDetail(response.data);
      })
      .catch((err) => console.log(err.message));
  }, [props.id]);

  const space = <Fragment>&nbsp;&nbsp;</Fragment>;

  //useMemo();
  // useMemo(() => {
  //   setCommentDetail();
  // }, [selectedId]);

  // JUST FOR EXPLNATION useMemo()=========================

  const expensiveComputation = (num) => {
    //console.log("Computation done!  "); //
    return num;
  };

  const memoizedValue = useMemo(() => expensiveComputation(value), [value]);
  // const memoizedValue = expensiveComputation(value); // Uncomment this and then click on the Hide/Show button to see how the value is loading everytime it is re-rendered

  const result = memoizedValue + 5;

  const memoizedFunction = (num) => {
    setValue(num);
    console.log("MEMOIZED VALUE:" + memoizedValue);
  };

  const useMemoDemo = (
    <div>
      <div>
        <input type="number" ref={textField} />
        <button onClick={() => memoizedFunction(textField.current.value)}>
          {" "}
          Compute
        </button>
      </div>
    </div>
  );

  const memorizedComponent = useMemo(() => {
    console.log("Rendering PostDetails");
    return (
      <div>
        <h3>ID: {props.id}</h3>
        <h3>Title: {props.title}</h3>
        <h3>Author: {props.author}</h3>

        <div style={{ textAlign: "left" }}>
          {space} Comments <br />
          {commentDetail != null
            ? commentDetail.map((c) => {
                return <Comment comment={c.name} key={c.id} />;
              })
            : null}
        </div>

        <div>
          <input
            type="button"
            value="delete"
            onClick={() => props.deletePost(props.id)}
          />
          <input type="button" value="edit" onClick={props.editPost} />
        </div>
        {useMemoDemo}
      </div>
    );
  }, [commentDetail]);
  return memorizedComponent;
};

export default PostDetails;
