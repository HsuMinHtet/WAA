import { useMemo } from "react";
import Post from "../../components/Post/Post";

const Posts = (props) => {
  const memorizedComponent = useMemo(() => {
    console.log("Rendering PostList");
    const postList = props.posts.map((post) => {
      return (
        <Post
          title={post.title}
          author={post.author}
          id={post.id}
          key={post.id}
          setSelected={() => {
            props.setSelected(post.id);
          }}
        />
      );
    });
    return postList;
  }, Post);
  return memorizedComponent;
};

export default Posts;
