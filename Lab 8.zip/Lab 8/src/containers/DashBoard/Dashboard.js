import React, { useEffect, useState } from "react";
import Posts from "../Posts/Posts";
import PostDetails from "../../components/PostDetails/PostDetails";
import axios from "axios";
import NewPost from "../../components/NewPost/NewPost";
import { ThemeColorContext } from "../../components/store/ThemeColor";

const Dashboard = () => {
  const [themeColorState, setThemeColorState] = useState({ color: "red" });
  const [flag, setFlag] = useState(true);
  const [selectedId, setSelectedId] = useState(0);
  const [selectedTitle, setSelectedTitle] = useState(null);
  const [selectedAuthor, setSelectedAuthor] = useState(null);

  const [postsState, setPostsState] = useState([
    { id: 1, title: "Business", author: "Timmy" },
    { id: 2, title: "Education", author: "Jhon" },
    { id: 3, title: "Science", author: "Rose" },
  ]);

  const [postState, setPostState] = useState({
    title: "",
  });

  const fetchPosts = () => {
    axios
      .get("http://localhost:8080/posts/")
      .then((response) => {
        setPostsState(response.data);
      })
      .catch((error) => {
        console.log(error.message);
      });
  };

  //fetchPosts();
  useEffect(() => {
    fetchPosts();
  }, [flag]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setPostState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const changeNameClicked = () => {
    const titleValue = postState.title;

    setPostsState((prevPosts) =>
      prevPosts.map((post) =>
        post.id === 1 ? { ...post, title: titleValue } : post
      )
    );
  };

  const deleteButtonClicked = (id) => {
    axios
      .delete("http://localhost:8080/posts/" + id, postState)
      .then((response) => {
        fetchPosts();
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const setSelected = (id) => {
    postsState.map((post) => {
      if (post.id === id) {
        setSelectedTitle(post.title);
        setSelectedAuthor(post.author);
      }
      return selectedId;
    });
    setSelectedId(id);
  };
  // //useMemo();
  // useMemo(() => {
  //   setSelected();
  // }, [selectedId]);

  const reviewColorHandler = () => {
    if (themeColorState.color === "red") {
      setThemeColorState({ color: "blue" });
    } else {
      setThemeColorState({ color: "red" });
    }
  };

  return (
    <ThemeColorContext.Provider value={themeColorState}>
      <div>
        <div className="Post">
          <Posts posts={postsState} setSelected={setSelected} />
        </div>

        <div>
          <input
            className="Field"
            label={"title"}
            name={"title"}
            onChange={handleInputChange}
          />
          <button onClick={changeNameClicked}>Change Name</button>
        </div>
        <div>
          <button onClick={reviewColorHandler}>Change color</button>
        </div>
        <div className="PostDetail">
          <PostDetails
            author={selectedAuthor}
            title={selectedTitle}
            id={selectedId}
            deletePost={deleteButtonClicked}
          />
        </div>
        <div>
          <NewPost changeFetchFlag={fetchPosts} />
        </div>
      </div>
    </ThemeColorContext.Provider>
  );
};

export default Dashboard;
